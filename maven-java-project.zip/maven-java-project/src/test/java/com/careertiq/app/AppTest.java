package com.careertiq.app;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class AppTest {
    @Test
    public void greetingIsExpected() {
        assertEquals("Hello World!", AppMessage.greeting());
    }
}
