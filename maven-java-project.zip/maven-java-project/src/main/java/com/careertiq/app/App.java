package com.careertiq.app;

public class App {
    public static void main(String[] args) {
        System.out.println(AppMessage.greeting());
    }
}
