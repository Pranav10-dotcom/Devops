package com.careertiq.app;

public final class AppMessage {
    private AppMessage() {}
    public static String greeting() {
        return "Hello World!";
    }
}
