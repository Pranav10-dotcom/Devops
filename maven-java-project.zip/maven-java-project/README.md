# Apache Maven Lifecycle Exercise

Project coordinates:
- groupId: `com.careertiq.app`
- artifactId: `maven-java-project`
- version: `1.0-SNAPSHOT`

## Run on Ubuntu 24.04

Install prerequisites:
```bash
sudo apt update
sudo apt install default-jdk maven curl -y
java -version
javac -version
mvn -version
```

If Archetype generation is failing because Maven cannot download its plugin, this project is already scaffolded. Copy this folder to Ubuntu, then run these commands from inside it:
```bash
mvn -U validate
mvn -U compile
mvn -U test
mvn -U package
java -cp target/maven-java-project-1.0-SNAPSHOT.jar com.careertiq.app.App
mvn clean
```

Expected application output after package:
```
Hello World!
```

Important: Maven still needs access to Maven Central to download build plugins and JUnit. A successful `curl -I https://repo.maven.apache.org/maven2/` only proves HTTPS access to the repository root; it does not prove every Maven artifact download works.

Do not submit invented screenshots. Capture the actual terminal outputs from your Ubuntu VM and place them in the report.
